package com.android.stunningbdg;

/**
 * Created by ASUS on 11/04/2018.
 */

public class Wisata {
    public String review;
    public String nama;
    public String rank;

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }
}
